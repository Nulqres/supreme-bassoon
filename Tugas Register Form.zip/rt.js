document.getElementById('dob').max = new Date().toISOString().split('T')[0];

const form = document.getElementById('registration');
const usersTableBody = document.querySelector('#usersTable tbody');
const errors = {
  name: document.querySelector('.error[data-for="name"]'),
  email: document.querySelector('.error[data-for="email"]'),
  dob: document.querySelector('.error[data-for="dob"]'),
  gender: document.querySelector('.error[data-for="gender"]'),
  password: document.querySelector('.error[data-for="password"]'),
  confirmPassword: document.querySelector('.error[data-for="confirmPassword"]'),
  terms: document.querySelector('.error[data-for="terms"]'),
};

function clearAllErrors() {
  Object.values(errors).forEach(e => e.textContent = '');
  document.querySelectorAll('.radio-wrapper').forEach(r => r.classList.remove('selected'));
}

function validateEmailFormat(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

document.querySelectorAll('.radio-wrapper input').forEach(radio => {
  radio.addEventListener('change', () => {
    document.querySelectorAll('.radio-wrapper').forEach(w => w.classList.remove('selected'));
    if (radio.checked) radio.closest('.radio-wrapper')?.classList.add('selected');
  });
});

form.addEventListener('submit', function(e){
  e.preventDefault();
  clearAllErrors();
  let valid = true;

  const name = form.name.value.trim();
  const email = form.email.value.trim();
  const dob = form.dob.value;
  const genderEl = document.querySelector('input[name="gender"]:checked');
  const gender = genderEl ? genderEl.value : '';
  const password = form.password.value;
  const confirmPassword = form.confirmPassword.value;
  const terms = form.terms.checked;

  if (!name) { errors.name.textContent = 'Nama wajib diisi.'; valid=false; }
  if (!email) { errors.email.textContent = 'Email wajib diisi.'; valid=false; }
  else if (!validateEmailFormat(email)) { errors.email.textContent = 'Format email tidak valid.'; valid=false; }
  if (!dob) { errors.dob.textContent = 'Tanggal lahir wajib diisi.'; valid=false; }
  if (!gender) { errors.gender.textContent = 'Pilih jenis kelamin.'; valid=false; }
  if (!password) { errors.password.textContent = 'Password wajib diisi.'; valid=false; }
  else if (password.length < 6) { errors.password.textContent = 'Minimal 6 karakter.'; valid=false; }
  if (!confirmPassword) { errors.confirmPassword.textContent = 'Konfirmasi password wajib diisi.'; valid=false; }
  else if (password !== confirmPassword) { errors.confirmPassword.textContent = 'Password tidak cocok.'; valid=false; }
  if (!terms) { errors.terms.textContent = 'Harus menyetujui syarat dan ketentuan.'; valid=false; }

  if (!valid) return;

  const tr = document.createElement('tr');
  const dt = new Date(dob);
  let formattedDob = dob;
  if (!isNaN(dt)) {
    const d = String(dt.getDate()).padStart(2,'0');
    const m = String(dt.getMonth()+1).padStart(2,'0');
    const y = dt.getFullYear();
    formattedDob = `${d}-${m}-${y}`;
  }
  tr.innerHTML = `<td>${name}</td><td>${email}</td><td>${formattedDob}</td><td>${gender}</td>`;
  usersTableBody.appendChild(tr);

  form.reset();
  document.querySelectorAll('.radio-wrapper').forEach(w => w.classList.remove('selected'));
});
